package com.politecnicomalaga.CONSUMIDORES;

import java.time.LocalTime;

public interface ConsumidorDeTemperaturas {
    public void setNuevaTemperatura(int temperatura, LocalTime hora);
}
