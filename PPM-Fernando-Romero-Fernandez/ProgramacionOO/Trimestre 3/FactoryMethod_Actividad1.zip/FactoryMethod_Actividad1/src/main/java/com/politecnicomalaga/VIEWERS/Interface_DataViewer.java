package com.politecnicomalaga.VIEWERS;

public interface Interface_DataViewer {
    String mostrarContenido();
}
