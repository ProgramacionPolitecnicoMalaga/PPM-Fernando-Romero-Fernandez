package com.politecnicomalaga.elementos.jugador;

public class Patton implements Jugador {
    public String getNombreJugador() {
        return "Patton";
    }
}
