package com.politecnicomalaga.elementos.villano;

public class Khan implements Villano {
    public String getNombreVillano() {
        return "Khan";
    }
}
