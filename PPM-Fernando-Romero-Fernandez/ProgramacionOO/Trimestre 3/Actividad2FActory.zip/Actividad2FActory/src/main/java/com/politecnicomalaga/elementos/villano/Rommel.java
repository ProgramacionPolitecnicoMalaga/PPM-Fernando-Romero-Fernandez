package com.politecnicomalaga.elementos.villano;

public class Rommel implements Villano {
    public String getNombreVillano() {
        return "Rommel";
    }
}
