package com.politecnicomalaga.elementos.obstaculo;

public class Tanques implements Obstaculo {
    public String getNombreObstaculo() {
        return "Tanques";
    }
}
