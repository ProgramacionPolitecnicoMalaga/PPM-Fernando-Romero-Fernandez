package com.politecnicomalaga.elementos.obstaculo;

public interface Obstaculo {
    public String getNombreObstaculo();
}
