package com.politecnicomalaga.elementos.obstaculo;

public class Naves_Klingon implements Obstaculo {
    public String getNombreObstaculo() {
        return "Naves Klingon";
    }
}
