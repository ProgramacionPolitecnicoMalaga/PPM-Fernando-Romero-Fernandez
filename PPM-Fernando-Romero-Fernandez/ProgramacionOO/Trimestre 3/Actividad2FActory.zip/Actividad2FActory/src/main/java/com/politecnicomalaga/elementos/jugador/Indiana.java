package com.politecnicomalaga.elementos.jugador;

public class Indiana implements Jugador{
    public String getNombreJugador() {
        return "Indiana";
    }
}
