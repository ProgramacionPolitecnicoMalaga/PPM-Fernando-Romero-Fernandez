package com.politecnicomalaga.elementos.jugador;

public class USS_Enterpise implements Jugador{
    public String getNombreJugador() {
        return "USS Enterprise";
    }
}
