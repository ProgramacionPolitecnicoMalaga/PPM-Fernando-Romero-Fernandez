package com.politecnicomalaga.elementos.obstaculo;

public class Carcelero_Turco implements Obstaculo {
    public String getNombreObstaculo() {
        return "Carcelero Turco";
    }
}
