package com.politecnicomalaga.elementos.villano;

public interface Villano {
    public String getNombreVillano();
}
