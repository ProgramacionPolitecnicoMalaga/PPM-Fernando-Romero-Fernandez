package com.politecnicomalaga.elementos.villano;

public class Molaram implements Villano{
    public String getNombreVillano() {
        return "Molaram";
    }
}
