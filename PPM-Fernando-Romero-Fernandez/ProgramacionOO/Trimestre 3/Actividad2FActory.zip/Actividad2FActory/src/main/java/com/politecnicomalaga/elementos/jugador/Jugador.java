package com.politecnicomalaga.elementos.jugador;

public interface Jugador {
    public String getNombreJugador();
}
