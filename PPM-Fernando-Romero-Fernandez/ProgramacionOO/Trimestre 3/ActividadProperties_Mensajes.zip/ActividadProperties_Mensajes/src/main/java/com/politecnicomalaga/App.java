package com.politecnicomalaga;

import com.politecnicomalaga.CONTROLADOR.CambioVentana;

import java.io.IOException;

public class App {


    public static void main(String[] args) throws IOException {
        CambioVentana cambioVentana = new CambioVentana();

    }
}
