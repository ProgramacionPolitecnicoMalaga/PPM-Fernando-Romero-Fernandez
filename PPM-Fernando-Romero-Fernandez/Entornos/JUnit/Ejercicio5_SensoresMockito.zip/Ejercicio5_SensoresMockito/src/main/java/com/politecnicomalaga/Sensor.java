package com.politecnicomalaga;

public class Sensor {
    public final static int NO_INICIADO = -1;
    public final static int ESTADO_VACIO = 0;
    public final static int ESTADO_CASI_VACIO = 1;
    public final static int ESTADO_MITAD = 2;
    public final static int ESTADO_CASI_LLENO = 3;
    public final static int ESTADO_LLENO = 4;
}
