package com.politecnicomalaga;

public class MatrizSensores {
    public int getEstadoSensor(int i){
        return Integer.MIN_VALUE;
    }
}
