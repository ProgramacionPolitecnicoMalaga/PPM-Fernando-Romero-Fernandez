package com.politecnicoMalaga;

public class ConversionMedidas {

    public double inchACm(double inches){
        return inches * 2.54;
    }

    public double cmAInch(double cms){
        return cms / 2.54;
    }
}
