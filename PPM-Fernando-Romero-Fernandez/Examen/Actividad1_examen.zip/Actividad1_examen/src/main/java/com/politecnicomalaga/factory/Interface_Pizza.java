package com.politecnicomalaga.factory;

public interface Interface_Pizza {
    public String preparar();
    public String hornear();
    public String cortar();
    public String empaquetar();
}
